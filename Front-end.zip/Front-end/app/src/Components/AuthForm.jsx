import React, { useState } from 'react';
const AuthForm = ({ isLogin, onSubmit }) => {
const [username, setUsername] = useState('');
const [email, setEmail] = useState('');
const [password, setPassword] = useState('');
const handleSubmit = (e) => {
e.preventDefault();
if (isLogin) {
    onSubmit(email, password);
} else {
    onSubmit(username, email, password);
    }
};
return (
<form onSubmit={handleSubmit}>
{!isLogin && (
<input type="text" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" required/>
)}
<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required/>
            
<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" required/>
<br></br>
<button type="submit">{isLogin ? 'Login' : 'Register'}</button>
</form>
);
};

export default AuthForm;