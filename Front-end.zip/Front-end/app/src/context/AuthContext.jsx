import React, { createContext, useState } from 'react';
import axios from 'axios';
const AuthContext = createContext();
const AuthProvider = ({ children }) => {
const [user, setUser ] = useState(null);
const login = async (email, password) => {
const response = await axios.post('http://localhost:5000/api/auth/login', { email, password });
setUser (response.data.user);
localStorage.setItem('token', response.data.token);
};

const register = async (username, email, password) => {
await axios.post('http://localhost:5000/api/auth/register', { username, email, password });
};
return (
<AuthContext.Provider value={{ user, login, register }}>
{children}
</AuthContext.Provider>
);
};
export { AuthContext, AuthProvider };