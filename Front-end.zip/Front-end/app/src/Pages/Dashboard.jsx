import React, { useContext, useEffect, useState } from 'react';
import { AuthContext } from '../context/AuthContext';
import axios from 'axios';
const Dashboard = () => {
const { user } = useContext(AuthContext);
const [posts, setPosts] = useState([]);
const [content, setContent] = useState('');
useEffect(() => {
const fetchPosts = async () => {
try {
const response = await axios.get('http://localhost:5000/api/posts'); // Adjust the endpoint as needed
setPosts(response.data);
} catch (error) {
console.error('Error fetching posts:', error);
}
};
fetchPosts();
}, []);

const handlePostSubmit = async (e) => {
e.preventDefault();
try {
await axios.post('http://localhost:5000/api/posts', { content }, {
headers: {Authorization: `Bearer ${localStorage.getItem('token')}`, 
},
});
setContent('');
const response = await axios.get('http://localhost:5000/api/posts');
setPosts(response.data);
} catch (error) {
console.error('Error creating post:', error);
}
};
return (
<div style={{ padding: '20px' }}>
<h2>Dashboard</h2>
<form onSubmit={handlePostSubmit}>
<textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Whats on your mind?" required
style={{ width: '100%', height: '100px' }}/>
<button type="submit">Post</button>
</form>
<h3>Your Posts</h3>
<ul>
{posts.map((post) => (
<li key={post._id}>
<p>{post.content}</p>
<small>Posted on: {new Date(post.createdAt).toLocaleString()}</small></li>))}
</ul>
</div>
);
};

export default Dashboard;