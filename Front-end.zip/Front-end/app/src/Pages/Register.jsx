import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import AuthForm from '../Components/AuthForm';
const Register = () => {
const { register } = useContext(AuthContext);
const handleRegister = async (username, email, password) => {
await register(username, email, password);
};
return (
<div>
<h2>Register</h2>
<AuthForm isLogin={false} onSubmit={handleRegister} />
</div>
);
};
export default Register;