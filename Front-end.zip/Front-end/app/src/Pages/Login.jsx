import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import AuthForm from '../Components/AuthForm';
import "./Login.css";
const Login = () => {
const { login } = useContext(AuthContext);
const handleLogin = async (email, password) => {
await login(email, password);
};

return (
<div>
  <h2>Login</h2>
  <AuthForm isLogin={true} onSubmit={handleLogin} />
</div>
);
};

export default Login;